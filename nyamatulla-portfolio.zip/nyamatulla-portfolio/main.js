/* ==========================================================================
   Nyamatulla Khan — Portfolio interactions (vanilla JS, no build step)
   ========================================================================== */
(() => {
  "use strict";

  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => Array.from(r.querySelectorAll(s));

  const root = document.documentElement;
  const body = document.body;
  const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)");
  const finePointer = window.matchMedia("(hover: hover) and (pointer: fine)");
  const EASE = "cubic-bezier(0.22, 1, 0.36, 1)";
  const DEFAULT_TITLE = document.title;

  const ORDER = ["about", "experience", "awards", "contact"];
  const TITLES = { about: "About", experience: "Experience", awards: "Awards", contact: "Contact" };

  /* ------------------------------------------------------------------
     1. Background video
     ------------------------------------------------------------------ */
  const video = $(".bg-video");
  if (video) {
    video.muted = true;
    const tryPlay = () => {
      const p = video.play();
      if (p && typeof p.catch === "function") p.catch(() => {});
    };
    tryPlay();
    document.addEventListener("visibilitychange", () => {
      if (!document.hidden) tryPlay();
    });
    window.addEventListener("pointerdown", tryPlay, { once: true, passive: true });
  }

  /* ------------------------------------------------------------------
     2. Entrance cleanup — drop the finished reveal so hover/parallax
        transforms are never fighting a held animation
     ------------------------------------------------------------------ */
  $$(".anim").forEach((el) => {
    el.addEventListener("animationend", (e) => {
      if (e.target === el) el.classList.add("is-in");
    });
  });

  /* ------------------------------------------------------------------
     3. Headline — split into letters for the split-flap hover flip
     ------------------------------------------------------------------ */
  const headline = $(".headline");
  if (headline) {
    $$(".line", headline).forEach((line) => {
      const text = line.textContent;
      const frag = document.createDocumentFragment();
      for (const ch of text) {
        if (ch === " ") {
          frag.append(" ");
          continue;
        }
        const s = document.createElement("span");
        s.className = "ch";
        s.textContent = ch;
        frag.append(s);
      }
      line.textContent = "";
      line.append(frag);
    });

    headline.addEventListener("pointerover", (e) => {
      if (reduceMotion.matches) return;
      const c = e.target.closest(".ch");
      if (c && !c.classList.contains("flip")) c.classList.add("flip");
    });
    headline.addEventListener("animationend", (e) => {
      const t = e.target;
      if (t.classList && t.classList.contains("ch")) t.classList.remove("flip");
    });
  }

  /* ------------------------------------------------------------------
     4. Pointer parallax — 3D hero tilt, video drift, spotlight
     ------------------------------------------------------------------ */
  const heroInner = $(".hero-inner");
  const glow = $(".bg-glow");
  let tx = 0, ty = 0, cx = 0, cy = 0, tiltRaf = 0;

  function tiltTick() {
    cx += (tx - cx) * 0.07;
    cy += (ty - cy) * 0.07;
    heroInner.style.setProperty("--tilt-x", (-cy * 7).toFixed(3) + "deg");
    heroInner.style.setProperty("--tilt-y", (cx * 9).toFixed(3) + "deg");
    if (video) {
      video.style.setProperty("--vx", (-cx * 22).toFixed(2) + "px");
      video.style.setProperty("--vy", (-cy * 14).toFixed(2) + "px");
    }
    if (Math.abs(tx - cx) > 0.0004 || Math.abs(ty - cy) > 0.0004) {
      tiltRaf = requestAnimationFrame(tiltTick);
    } else {
      tiltRaf = 0;
    }
  }

  function onPointerMove(e) {
    if (e.pointerType === "touch") return;
    tx = e.clientX / window.innerWidth - 0.5;
    ty = e.clientY / window.innerHeight - 0.5;
    if (glow) {
      glow.style.setProperty("--gx", e.clientX + "px");
      glow.style.setProperty("--gy", e.clientY + "px");
    }
    body.classList.add("has-pointer");
    if (!tiltRaf) tiltRaf = requestAnimationFrame(tiltTick);
  }

  function resetTilt() {
    tx = 0;
    ty = 0;
    body.classList.remove("has-pointer");
    if (!tiltRaf) tiltRaf = requestAnimationFrame(tiltTick);
  }

  if (heroInner && finePointer.matches && !reduceMotion.matches) {
    window.addEventListener("pointermove", onPointerMove, { passive: true });
    root.addEventListener("mouseleave", resetTilt);
  }

  /* magnetic CTA */
  const heroCta = $(".hero .cta");
  if (heroCta && finePointer.matches && !reduceMotion.matches) {
    heroCta.addEventListener("pointermove", (e) => {
      const r = heroCta.getBoundingClientRect();
      heroCta.style.setProperty("--mx", ((e.clientX - (r.left + r.width / 2)) * 0.22).toFixed(1) + "px");
      heroCta.style.setProperty("--my", ((e.clientY - (r.top + r.height / 2)) * 0.3).toFixed(1) + "px");
    });
    heroCta.addEventListener("pointerleave", () => {
      heroCta.style.setProperty("--mx", "0px");
      heroCta.style.setProperty("--my", "0px");
    });
  }

  /* ------------------------------------------------------------------
     5. Stats count-up (easeOutCubic, once, IntersectionObserver .25)
     ------------------------------------------------------------------ */
  const statValues = $$(".stat-value");
  const easeOutCubic = (t) => 1 - Math.pow(1 - t, 3);
  const formatStat = (el, v) => {
    const d = parseInt(el.dataset.decimals || "0", 10);
    return (el.dataset.prefix || "") + v.toFixed(d) + (el.dataset.suffix || "");
  };

  if (reduceMotion.matches || !("IntersectionObserver" in window)) {
    statValues.forEach((el) => (el.textContent = formatStat(el, parseFloat(el.dataset.target))));
  } else {
    statValues.forEach((el) => (el.textContent = formatStat(el, parseFloat(el.dataset.from || "0"))));
    const io = new IntersectionObserver(
      (entries, obs) => {
        entries.forEach((entry) => {
          if (!entry.isIntersecting) return;
          obs.unobserve(entry.target);
          const el = entry.target;
          const i = statValues.indexOf(el);
          const from = parseFloat(el.dataset.from || "0");
          const to = parseFloat(el.dataset.target);
          const duration = 1500 + i * 80;
          const delay = 480 + i * 90;
          setTimeout(() => {
            const t0 = performance.now();
            const stepFn = (now) => {
              const t = Math.min(1, (now - t0) / duration);
              el.textContent = formatStat(el, from + (to - from) * easeOutCubic(t));
              if (t < 1) requestAnimationFrame(stepFn);
              else el.textContent = formatStat(el, to);
            };
            requestAnimationFrame(stepFn);
          }, delay);
        });
      },
      { threshold: 0.25 }
    );
    statValues.forEach((el) => io.observe(el));
  }

  /* ------------------------------------------------------------------
     6. Toast
     ------------------------------------------------------------------ */
  const toastEl = $(".toast");
  let toastTimer = 0;
  function toast(msg) {
    if (!toastEl) return;
    toastEl.textContent = msg;
    toastEl.classList.add("is-show");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => toastEl.classList.remove("is-show"), 2200);
  }

  async function copyText(text) {
    let ok = false;
    try {
      await navigator.clipboard.writeText(text);
      ok = true;
    } catch (_) {
      const ta = document.createElement("textarea");
      ta.value = text;
      ta.setAttribute("readonly", "");
      ta.style.position = "fixed";
      ta.style.opacity = "0";
      document.body.append(ta);
      ta.select();
      try {
        ok = document.execCommand("copy");
      } catch (_) {
        ok = false;
      }
      ta.remove();
    }
    if (!ok) toast(text);
    else toast(text.includes("@") ? "Email copied to clipboard" : "Copied to clipboard");
  }

  /* ------------------------------------------------------------------
     7. Mobile menu
     ------------------------------------------------------------------ */
  const burger = $(".burger");
  const menu = $("#mobile-menu");
  const menuOverlay = $("#menu-overlay");
  const isMenuOpen = () => burger && burger.getAttribute("aria-expanded") === "true";

  function setMenu(open) {
    if (!burger) return;
    burger.setAttribute("aria-expanded", String(open));
    burger.setAttribute("aria-label", open ? "Close menu" : "Open menu");
    menu.hidden = !open;
    menuOverlay.hidden = !open;
    body.classList.toggle("menu-open", open);
    if (open) {
      const first = $(".m-link.is-active", menu) || $("a", menu);
      if (first) first.focus({ preventScroll: true });
    }
  }

  if (burger) {
    burger.addEventListener("click", () => setMenu(!isMenuOpen()));
    menuOverlay.addEventListener("click", () => setMenu(false));
  }

  /* ------------------------------------------------------------------
     8. Panels — 3D page transitions + hash routing
     ------------------------------------------------------------------ */
  const panelsEl = $("#panels");
  const header = $(".header");
  let current = null;
  let returnFocus = null;

  function setPanelTop() {
    if (!header) return;
    const bottom = header.offsetTop + header.offsetHeight;
    root.style.setProperty("--panel-top", Math.round(bottom + 14) + "px");
  }
  setPanelTop();
  if (document.fonts && document.fonts.ready) document.fonts.ready.then(setPanelTop);

  window.addEventListener("resize", () => {
    if (window.innerWidth > 720 && isMenuOpen()) setMenu(false);
    setPanelTop();
  });

  // progress dots in every panel footer
  $$("[data-progress]").forEach((wrap) => {
    ORDER.forEach((id) => {
      const b = document.createElement("button");
      b.type = "button";
      b.dataset.go = id;
      b.setAttribute("aria-label", "Go to " + TITLES[id]);
      wrap.append(b);
    });
  });

  function syncNav(id) {
    const key = id || "home";
    $$("[data-go]").forEach((el) => {
      if (el.parentElement && el.parentElement.hasAttribute("data-progress")) {
        el.setAttribute("aria-current", el.dataset.go === key ? "true" : "false");
        return;
      }
      if (!el.matches(".nav-link, .m-link, .sign-in")) return;
      const on = el.dataset.go === key;
      el.classList.toggle("is-active", on);
      if (on && !el.matches(".sign-in")) el.setAttribute("aria-current", "page");
      else el.removeAttribute("aria-current");
    });
  }

  const PERSP = "perspective(1600px)";
  const REST = `${PERSP} translate3d(0px, 0px, 0px) rotateX(0deg) rotateY(0deg) scale(1)`;

  function play(el, frames, opts) {
    if (el._anim) {
      el._anim.cancel();
      el._anim = null;
    }
    if (reduceMotion.matches || typeof el.animate !== "function") return null;
    const a = el.animate(frames, Object.assign({ easing: EASE, fill: "both" }, opts));
    el._anim = a;
    return a;
  }

  function enter(el, dir) {
    el.classList.remove("is-leaving");
    el.classList.add("is-active");
    el.style.visibility = "";
    el.style.pointerEvents = "";
    const scroller = $(".panel-body", el);
    if (scroller) scroller.scrollTop = 0;

    const from =
      dir === 0
        ? `${PERSP} translate3d(0px, 46px, -140px) rotateX(16deg) rotateY(0deg) scale(0.96)`
        : `${PERSP} translate3d(${dir * 16}%, 0px, -180px) rotateX(0deg) rotateY(${dir * -28}deg) scale(0.96)`;

    const a = play(
      el,
      [
        { opacity: 0, transform: from },
        { opacity: 1, transform: REST },
      ],
      { duration: dir === 0 ? 760 : 680 }
    );
    if (a) {
      a.onfinish = () => {
        if (el._anim === a) {
          a.cancel();
          el._anim = null;
        }
      };
    }
  }

  function leave(el, dir) {
    el.classList.remove("is-active");
    el.classList.add("is-leaving");
    el.style.visibility = "visible";
    el.style.pointerEvents = "none";

    const to =
      dir === 0
        ? `${PERSP} translate3d(0px, 30px, -120px) rotateX(10deg) rotateY(0deg) scale(0.97)`
        : `${PERSP} translate3d(${-dir * 16}%, 0px, -180px) rotateX(0deg) rotateY(${dir * 28}deg) scale(0.96)`;

    const a = play(
      el,
      [
        { opacity: 1, transform: REST },
        { opacity: 0, transform: to },
      ],
      { duration: dir === 0 ? 420 : 460, easing: "cubic-bezier(0.4, 0, 0.2, 1)" }
    );

    const done = () => {
      if (!el.classList.contains("is-active")) {
        el.style.visibility = "";
        el.classList.remove("is-leaving");
      }
      el.style.pointerEvents = "";
      if (a && el._anim === a) {
        a.cancel();
        el._anim = null;
      }
    };
    if (a) a.onfinish = done;
    else done();
  }

  function go(id, opts = {}) {
    const push = opts.push !== false;
    if (!id || id === "home" || !ORDER.includes(id)) {
      closePanels(opts);
      return;
    }
    if (id === current) return;
    const next = $("#panel-" + id);
    if (!next) return;

    const prevId = current;
    const prev = prevId ? $("#panel-" + prevId) : null;
    const dir = prev ? Math.sign(ORDER.indexOf(id) - ORDER.indexOf(prevId)) : 0;

    if (!prevId) {
      const ae = document.activeElement;
      returnFocus = ae && ae !== body ? ae : null;
      panelsEl.classList.add("is-open");
      panelsEl.setAttribute("aria-hidden", "false");
      body.classList.add("panel-open");
    }

    current = id;
    syncNav(id);
    if (push) history.pushState({ panel: id }, "", "#" + id);
    document.title = TITLES[id] + " · Nyamatulla Khan";

    if (prev) leave(prev, dir);
    enter(next, dir);
    if (sphere) sphere.setActive(id === "about");
    requestAnimationFrame(() => next.focus({ preventScroll: true }));
  }

  function closePanels(opts = {}) {
    const push = opts.push !== false;
    syncNav(null);
    document.title = DEFAULT_TITLE;
    if (!current) return;

    const el = $("#panel-" + current);
    current = null;
    if (push) history.pushState({ panel: null }, "", location.pathname + location.search);

    leave(el, 0);
    panelsEl.classList.remove("is-open");
    panelsEl.setAttribute("aria-hidden", "true");
    body.classList.remove("panel-open");
    if (sphere) sphere.setActive(false);

    const f = returnFocus;
    returnFocus = null;
    if (f && document.contains(f) && f.getClientRects().length) f.focus({ preventScroll: true });
  }

  function step(delta) {
    const i = current ? ORDER.indexOf(current) : -1;
    const n = (i + delta + ORDER.length) % ORDER.length;
    go(ORDER[n]);
  }

  /* delegated clicks */
  document.addEventListener("click", (e) => {
    const t = e.target.closest("[data-go], [data-close], [data-step], [data-copy]");
    if (!t) return;
    e.preventDefault();

    if (t.hasAttribute("data-copy")) {
      copyText(t.dataset.copy);
      return;
    }
    if (isMenuOpen()) setMenu(false);

    if (t.hasAttribute("data-close")) closePanels();
    else if (t.hasAttribute("data-step")) step(parseInt(t.dataset.step, 10) || 1);
    else go(t.dataset.go);
  });

  /* keyboard */
  const FOCUSABLE = 'a[href], button:not([disabled]), [tabindex]:not([tabindex="-1"])';

  function trapFocus(e, container) {
    const items = $$(FOCUSABLE, container).filter(
      (el) => el.getClientRects().length && getComputedStyle(el).visibility !== "hidden"
    );
    if (!items.length) return;
    const first = items[0];
    const last = items[items.length - 1];
    const active = document.activeElement;
    if (!container.contains(active)) {
      e.preventDefault();
      first.focus();
    } else if (e.shiftKey && (active === first || active === container)) {
      e.preventDefault();
      last.focus();
    } else if (!e.shiftKey && active === last) {
      e.preventDefault();
      first.focus();
    }
  }

  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape") {
      if (isMenuOpen()) {
        setMenu(false);
        burger.focus();
        return;
      }
      if (current) {
        closePanels();
        return;
      }
    }

    if (e.key === "Tab") {
      if (isMenuOpen()) return;
      if (current) trapFocus(e, $("#panel-" + current));
      return;
    }

    if (current && !isMenuOpen() && !e.altKey && !e.metaKey && !e.ctrlKey && !e.shiftKey) {
      if (e.key === "ArrowRight") {
        e.preventDefault();
        step(1);
      } else if (e.key === "ArrowLeft") {
        e.preventDefault();
        step(-1);
      }
    }
  });

  /* history */
  window.addEventListener("popstate", () => {
    const id = location.hash.slice(1);
    go(ORDER.includes(id) ? id : "home", { push: false });
  });

  /* scroll / swipe on the landing view opens About */
  let wheelLock = 0;
  window.addEventListener(
    "wheel",
    (e) => {
      if (current || isMenuOpen()) return;
      const now = performance.now();
      if (now < wheelLock) return;
      if (e.deltaY > 30) {
        wheelLock = now + 1200;
        go("about");
      }
    },
    { passive: true }
  );

  const pageEl = $(".page");
  let touchY = null;
  if (pageEl) {
    pageEl.addEventListener("touchstart", (e) => (touchY = e.touches[0].clientY), { passive: true });
    pageEl.addEventListener(
      "touchend",
      (e) => {
        if (touchY === null || current || isMenuOpen()) return;
        const dy = touchY - e.changedTouches[0].clientY;
        touchY = null;
        if (dy > 70) go("about");
      },
      { passive: true }
    );
  }

  /* ------------------------------------------------------------------
     9. 3D tilt cards (experience + awards)
     ------------------------------------------------------------------ */
  function bindTilt(el) {
    const max = parseFloat(el.dataset.tilt) || 6;
    const zone = el.closest(".flip") || el.parentElement || el;
    zone.addEventListener("pointermove", (e) => {
      if (e.pointerType !== "mouse") return;
      const r = zone.getBoundingClientRect();
      const px = (e.clientX - r.left) / r.width;
      const py = (e.clientY - r.top) / r.height;
      el.style.setProperty("--ry", ((px - 0.5) * max * 2).toFixed(2) + "deg");
      el.style.setProperty("--rx", ((0.5 - py) * max * 2).toFixed(2) + "deg");
      el.style.setProperty("--gx", (px * 100).toFixed(1) + "%");
      el.style.setProperty("--gy", (py * 100).toFixed(1) + "%");
      el.classList.add("is-tilting");
    });
    zone.addEventListener("pointerleave", () => {
      el.style.setProperty("--rx", "0deg");
      el.style.setProperty("--ry", "0deg");
      el.classList.remove("is-tilting");
    });
  }
  if (finePointer.matches && !reduceMotion.matches) $$("[data-tilt]").forEach(bindTilt);

  /* award flip cards */
  $$(".flip").forEach((card) => {
    const toggle = () => {
      const on = card.classList.toggle("is-flipped");
      card.setAttribute("aria-pressed", String(on));
    };
    card.addEventListener("click", () => {
      if (!finePointer.matches) toggle();
    });
    card.addEventListener("keydown", (e) => {
      if (e.key === "Enter" || e.key === " ") {
        e.preventDefault();
        toggle();
      }
    });
  });

  /* ------------------------------------------------------------------
     10. 3D skill sphere
     ------------------------------------------------------------------ */
  const SKILLS = [
    "Internet of Things",
    "Generative AI",
    "Machine Learning",
    "Artificial Intelligence",
    "JavaScript",
    "HTML",
    "CSS",
    "Web Development",
    "Project Management",
    "Team Leadership",
    "Collaboration",
    "Presentation",
    "Communication",
    "Problem Solving",
    "Social Media",
    "Organisation",
    "Startup Pitching",
  ];

  function createSphere(host, words) {
    const pts = [];
    const tags = [];
    const n = words.length;

    words.forEach((w, i) => {
      const phi = Math.acos(-1 + (2 * i + 1) / n);
      const theta = Math.sqrt(n * Math.PI) * phi;
      pts.push({
        x: Math.cos(theta) * Math.sin(phi),
        y: Math.sin(theta) * Math.sin(phi),
        z: Math.cos(phi),
      });
      const t = document.createElement("span");
      t.className = "sphere-tag";
      t.textContent = w;
      host.append(t);
      tags.push(t);
    });

    const still = reduceMotion.matches;
    const IDLE_X = -0.0016;
    const IDLE_Y = 0.0042;
    let size = host.clientWidth || 300;
    let vx = 0, vy = 0;
    let active = false, raf = 0;
    let dragging = false, moved = false, lastX = 0, lastY = 0, downTag = null;
    let focusIdx = -1;

    function rotate(ax, ay) {
      const cX = Math.cos(ax), sX = Math.sin(ax), cY = Math.cos(ay), sY = Math.sin(ay);
      for (const p of pts) {
        const y1 = p.y * cX - p.z * sX;
        const z1 = p.y * sX + p.z * cX;
        const x2 = p.x * cY + z1 * sY;
        const z2 = -p.x * sY + z1 * cY;
        p.x = x2;
        p.y = y1;
        p.z = z2;
      }
    }

    function rotateAxis(kx, ky, kz, ang) {
      const c = Math.cos(ang), s = Math.sin(ang), t = 1 - c;
      for (const p of pts) {
        const dot = kx * p.x + ky * p.y + kz * p.z;
        const crx = ky * p.z - kz * p.y;
        const cry = kz * p.x - kx * p.z;
        const crz = kx * p.y - ky * p.x;
        const nx = p.x * c + crx * s + kx * dot * t;
        const ny = p.y * c + cry * s + ky * dot * t;
        const nz = p.z * c + crz * s + kz * dot * t;
        p.x = nx;
        p.y = ny;
        p.z = nz;
      }
    }

    // rotate the whole sphere so pts[i] travels toward the viewer
    function pullToFront(i, amt) {
      const p = pts[i];
      const ax = p.y, ay = -p.x;
      const len = Math.hypot(ax, ay);
      if (len < 1e-4) {
        if (p.z < 0) rotate(0, 0.05);
        return;
      }
      const ang = Math.acos(Math.max(-1, Math.min(1, p.z)));
      rotateAxis(ax / len, ay / len, 0, ang * amt);
    }

    function render() {
      const R = size * 0.38;
      const d = 2.6;
      for (let i = 0; i < pts.length; i++) {
        const p = pts[i];
        const s = d / (d - p.z);
        const x = p.x * R * s * 0.8;
        const y = p.y * R * s * 0.8;
        const depth = (p.z + 1) / 2;
        const sc = 0.55 + depth * 0.5;
        const el = tags[i];
        el.style.transform = `translate(-50%, -50%) translate3d(${x.toFixed(1)}px, ${y.toFixed(1)}px, 0) scale(${sc.toFixed(3)})`;
        el.style.opacity = (0.16 + depth * 0.84).toFixed(3);
        el.style.zIndex = String(Math.round(depth * 100));
      }
    }

    function frame() {
      if (!active) {
        raf = 0;
        return;
      }
      if (!dragging) {
        if (focusIdx >= 0) {
          pullToFront(focusIdx, 0.12);
          vx *= 0.9;
          vy *= 0.9;
        } else if (!still) {
          vx += (IDLE_X - vx) * 0.02;
          vy += (IDLE_Y - vy) * 0.02;
          rotate(vx, vy);
        } else {
          vx *= 0.92;
          vy *= 0.92;
          rotate(vx, vy);
        }
      }
      render();
      raf = requestAnimationFrame(frame);
    }

    function kick() {
      if (active && !raf) raf = requestAnimationFrame(frame);
    }

    function setHot(i) {
      tags.forEach((t, j) => t.classList.toggle("is-hot", j === i));
      $$(".chip[data-skill]").forEach((c) => c.classList.toggle("is-hot", i >= 0 && c.dataset.skill === words[i]));
    }

    host.addEventListener("pointerdown", (e) => {
      dragging = true;
      moved = false;
      lastX = e.clientX;
      lastY = e.clientY;
      downTag = e.target.closest(".sphere-tag");
      host.classList.add("is-dragging");
      try {
        host.setPointerCapture(e.pointerId);
      } catch (_) {}
    });

    host.addEventListener("pointermove", (e) => {
      if (!dragging) return;
      const dx = e.clientX - lastX;
      const dy = e.clientY - lastY;
      lastX = e.clientX;
      lastY = e.clientY;
      if (Math.abs(dx) + Math.abs(dy) > 2) {
        if (!moved) {
          focusIdx = -1;
          setHot(-1);
        }
        moved = true;
      }
      const k = 0.0085;
      vx = -dy * k;
      vy = dx * k;
      rotate(vx, vy);
      kick();
    });

    const end = (e) => {
      if (!dragging) return;
      dragging = false;
      host.classList.remove("is-dragging");
      try {
        host.releasePointerCapture(e.pointerId);
      } catch (_) {}
      if (!moved && downTag) {
        const i = tags.indexOf(downTag);
        focusIdx = i;
        setHot(i);
        kick();
      }
      downTag = null;
    };
    host.addEventListener("pointerup", end);
    host.addEventListener("pointercancel", end);

    if ("ResizeObserver" in window) {
      new ResizeObserver(() => {
        size = host.clientWidth || size;
        render();
      }).observe(host);
    }

    document.addEventListener("visibilitychange", () => {
      if (document.hidden) active = false;
      else if (current === "about") {
        active = true;
        kick();
      }
    });

    render();

    return {
      setActive(on) {
        active = on;
        if (on) {
          size = host.clientWidth || size;
          kick();
        }
      },
      focusSkill(name) {
        const i = words.indexOf(name);
        if (i < 0) return;
        focusIdx = i;
        setHot(i);
        kick();
      },
      release() {
        focusIdx = -1;
        setHot(-1);
      },
    };
  }

  const sphereHost = $("#skill-sphere");
  const sphere = sphereHost ? createSphere(sphereHost, SKILLS) : null;

  if (sphere) {
    $$(".chip[data-skill]").forEach((chip) => {
      chip.addEventListener("pointerenter", (e) => {
        if (e.pointerType === "mouse") sphere.focusSkill(chip.dataset.skill);
      });
      chip.addEventListener("pointerleave", (e) => {
        if (e.pointerType === "mouse") sphere.release();
      });
      chip.addEventListener("click", () => sphere.focusSkill(chip.dataset.skill));
    });
  }

  /* ------------------------------------------------------------------
     11. Small details — year, live local time
     ------------------------------------------------------------------ */
  const yearEl = $("[data-year]");
  if (yearEl) yearEl.textContent = String(new Date().getFullYear());

  const timeEl = $("[data-local-time]");
  if (timeEl && window.Intl && Intl.DateTimeFormat) {
    const f = new Intl.DateTimeFormat("en-IN", {
      timeZone: "Asia/Kolkata",
      hour: "numeric",
      minute: "2-digit",
      hour12: true,
    });
    const tick = () => (timeEl.textContent = f.format(new Date()).toUpperCase() + " IST");
    tick();
    setInterval(tick, 30000);
  }

  /* ------------------------------------------------------------------
     12. Deep links — /#experience opens straight to that panel
     ------------------------------------------------------------------ */
  const initial = location.hash.slice(1);
  if (ORDER.includes(initial)) {
    setTimeout(() => go(initial, { push: false }), reduceMotion.matches ? 0 : 450);
  }
})();
